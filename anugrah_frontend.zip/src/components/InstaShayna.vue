<template>
  <!-- Instagram Section Begin -->
  <div class="instagram-photo">
    <div class="insta-item set-bg" style="background-image: url('/img/instag1.png')">
      <div class="inside-text">
        <i class="ti-instagram"></i>
        <h5>
          <a href="#">anugrahcouture</a>
        </h5>
      </div>
    </div>
    <div class="insta-item set-bg" style="background-image: url('/img/instag2.png')">
      <div class="inside-text">
        <i class="ti-instagram"></i>
        <h5>
          <a href="#">anugrahcouture</a>
        </h5>
      </div>
    </div>
    <div class="insta-item set-bg" style="background-image: url('/img/instag3.png')">
      <div class="inside-text">
        <i class="ti-instagram"></i>
        <h5>
          <a href="#">anugrahcouture</a>
        </h5>
      </div>
    </div>
    <div class="insta-item set-bg" style="background-image: url('/img/instag4.png')">
      <div class="inside-text">
        <i class="ti-instagram"></i>
        <h5>
          <a href="#">anugrahcouture</a>
        </h5>
      </div>
    </div>
    <div class="insta-item set-bg" style="background-image: url('/img/instag5.png')">
      <div class="inside-text">
        <i class="ti-instagram"></i>
        <h5>
          <a href="#">anugrahcouture</a>
        </h5>
      </div>
    </div>
    <div class="insta-item set-bg" style="background-image: url('/img/instag6.png')">
      <div class="inside-text">
        <i class="ti-instagram"></i>
        <h5>
          <a href="#">anugrahcouture</a>
        </h5>
      </div>
    </div>
  </div>
  <!-- Instagram Section End -->
</template>

<script>
export default {
  name: "InstaShayna"
};
</script>