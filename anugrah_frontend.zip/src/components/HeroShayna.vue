<template>
    <!-- Hero Section Begin -->
    <section class="hero-section">
      <carousel class="hero-items" :items="1" :nav="false" :autoplay="true">

        <div class="single-hero-items set-bg" style="background-image: url('/img/brk1.png')">
          <div class="container">
            <div class="row">
              <div class="col-lg-5">
                <span>Semi Prancis</span>
                <h1>Brokat</h1>
                <p>Handfeel soft, looks elegant, not allergic, and not fade ... Sweet reminder, we look forward to serving you all the time</p>
                <a href="#" class="primary-btn">Shop Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="single-hero-items set-bg" style="background-image: url('/img/brk2.png')">
          <div class="container">
            <div class="row">
              <div class="col-lg-5">
                <span>Semi Prancis</span>
                <h1>Brokat</h1>
                <p>Handfeel soft, looks elegant, not allergic, and not fade ... Sweet reminder, we look forward to serving you all the time</p>
                <a href="#" class="primary-btn">Shop Now</a>
              </div>
            </div>
          </div>
        </div>
        <div class="single-hero-items set-bg" style="background-image: url('/img/brk3.png')">
          <div class="container">
            <div class="row">
              <div class="col-lg-5">
                <span>semi Prancis</span>
                <h1>Brokat</h1>
                <p>Handfeel soft, looks elegant, not allergic, and not fade ... Sweet reminder, we look forward to serving you all the time</p>
                <a href="#" class="primary-btn">Shop Now</a>
              </div>
            </div>
          </div>
        </div>

      </carousel>
    </section>
    <!-- Hero Section End -->
</template>

<script>
import carousel from "vue-owl-carousel";

export default {
    name: "HeroShayna",
    components: {
        carousel
    }
}
</script>